# Museum of Graphics

**From one dot to a ray of light.** A playable history of computer graphics in seventeen rooms, built with Three.js and the Web Audio API.

You start with a single phosphor dot. It bursts into a path-traced scene, then rewinds through sixty years of graphics back down to a blinking terminal cursor. From there you rebuild everything one idea at a time, and the cursor travels with you. You redraw it as a glyph, then as a sprite, it gets voxelized into 3D, and at the end it's a glowing block in a path-traced room.

There are no images, videos or audio files in this project. Every pixel and every note is generated live in the browser.

## The rooms

| # | Era | What you do there |
|---|-----|-------------------|
| 01 | **The Character** · 1960s–70s | A real character terminal driven by a font ROM built at runtime. Hover any letter to see its 96 dots. Design your own cursor glyph. `RENDER` draws 3D in ASCII. There's a hidden text adventure. |
| 02 | **The Beam** · 1962–1985 | A simulated vector display with a display list, beam speed, phosphor decay and a flicker budget. Draw a closed shape and it becomes your ship. In XY scope mode, the sound you hear *is* the picture. |
| — | *Journey: inside the tube* | The camera swings behind the monitor, the shell fades, and you watch the electron gun sweep the raster. |
| 03 | **The Pixel** · 1977–1990 | An indexed 256×192 framebuffer. Paint your sprite, edit the 12-bit palette, see palette cycling redraw 0 pixels, and find the message hidden by a palette trick. |
| 04 | **Depth Without 3D** · 1982–1995 | A parallax runner. Press *Explode* and the six layers fly out of the monitor as glass slides in 3D. |
| 05 | **The Illusion of a World** · 1991–1994 | A raycaster with a live map, one ray per column, a fisheye bug toggle, slow scan, a maze, and a push-wall secret room. |
| — | *Dive through the glass* | The camera pushes through the screen into real 3D. |
| 06 | **The Vertex** · 1963–1985 | Your sprite as a voxel lattice. Hover any vertex to follow it through model → world → view → clip → NDC → pixel. Step outside the camera to watch the image form on its image plane, and do a dolly-zoom from perspective to orthographic. |
| 07 | **The Triangle** · 1967–1995 | A rasterizer lab (edge functions, barycentric blending), the depth buffer, the painter's algorithm failing, overdraw, and backface culling. |
| 08 | **Light & Normals** · 1971–1977 | Flat / Gouraud / Phong / Blinn on the same objects, a light you can grab, and an N·L probe. |
| 09 | **The Magic Number** · 1999 | A 3D front panel with 32 toggle switches for the bits of a float. Step through the fast inverse square root, then try to beat 0x5F3759DF. |
| 10 | **Wallpaper for Triangles** · 1974–1995 | UV lookup, affine vs perspective-correct mapping with vertex snapping (the PS1 wobble), filtering, and mip levels you can see. |
| 11 | **The Jaggies** · 1977–2009 | Huge pixels, SSAA and MSAA, and a lab showing sample patterns inside a pixel. |
| — | *Journey: follow the electricity* | Down a cable, across a motherboard, into the GPU die, where thousands of cores flash and a 4×4 matrix multiplies a vertex. |
| 12 | **The Glow** · 2001–2013 | HDR → bright pass → blur pyramid → composite → tone map, with every stage viewable. A 3×3 kernel editor and light painting. |
| 13 | **The Frame, Dissected** · 2010s | A frame pulled apart into eleven passes as an exploded 3D stack (geometry, depth, normals, albedo, shadow map, direct, specular, fog, HDR, bloom, final), plus a live GLSL lighting function you can edit and recompile. |
| 14 | **Worlds from Formulas** · demoscene | A signed-distance-field ray marcher: smooth union, space folding, step heatmap, distance-field slice, and a 2D sphere-tracing diagram. |
| 15 | **The Optics Bench** | Five puzzles with mirrors, a lens, a glass block and a prism, running on the same reflection and Snell's-law math as the ray tracer. |
| 16 | **Simulating Light** · 1980 · 1986 · 2018 | A progressive GPU path tracer. Change bounces and materials, and click any pixel to see one ray's path drawn in 3D. |
| 17 | **From One Dot** | The opening image again, now that you've built it. Your glyph, your sprite, your stats and a share postcard. |

The interface changes with every era: phosphor terminal and line-printer paper → lab instrument panel → one-bit desktop → '87 colour workbench → early-90s bevels → late-90s gradient title bars → gel & brushed metal → mid-2000s gloss → flat → glass.

The 32 hidden secrets are tracked in the ◆ counter, which gives hints for the ones you haven't found.

## Running it

It's a static site with no build step. Serve the folder with any static server:

```sh
python3 -m http.server 8000
# or
npx serve .
```

Then open http://localhost:8000. Opening `index.html` directly from disk won't work, because browsers block ES modules on `file://`.

Add `?q=low` to the URL to force the lightweight path tracer on slow machines. The heavy rooms also lower their resolution automatically when the frame rate drops.

## Deploying to GitHub Pages

1. Push this folder to a GitHub repository.
2. Go to **Settings → Pages → Build and deployment**, choose *Deploy from a branch*, then `main` / `root`.
3. The site will be at `https://<user>.github.io/<repo>/`.

`og.jpg` and the Open Graph tags give it a preview card when the link is shared. Each room has a deep link (`#terminal`, `#raycast`, `#optics`, `#raytrace`…). The share postcard's link carries the visitor's sprite in `?s=`, so a friend who opens it starts with that sprite.

## Single-file build

```sh
npm install
node build-artifact.mjs   # writes dist/museum-of-graphics.html
```

This bundles everything, including Three.js, into one self-contained HTML body.

## Structure

```
index.html            page shell and import map
styles.css            layout + one interface skin per era
lib/                  three.module.min.js (r169), vendored
src/main.js           app: chapter manager, transitions (glitch, dissolve, dive, journeys), input, loop
src/core/             audio engine, CRT monitor model + shader, UI windows, persistent state, share postcard
src/gfx/              path tracer (GPU + JS mirror), stroke font, bitmap font, 3D lab helpers
src/chapters/         one module per room, plus journeys.js
```

Every chapter has the same shape: `init`, `enter`, `exit`, `update`, and either `draw` (2D rooms drawn onto the CRT) or `render` (3D rooms).

## Audio

`src/core/audio.js` is a small synthesizer and sequencer. One original melody, the "cursor theme" in D minor, is re-orchestrated for each era: teletype beeps, pure sines, pulse-wave chiptune, a dark MIDI-style mix, FM bells, supersaw pads and an ambient finale. Sound effects (key clicks, degauss, beam zaps, glitches) are synthesized the same way.

## Notes

All artwork, music, code and text are original. Historical games and systems are only referred to, never reproduced, and the fast inverse square root is written from scratch in JavaScript.

Fonts come from Google Fonts: Instrument Serif, Geist, JetBrains Mono, IBM Plex Sans, VT323 and Silkscreen.
